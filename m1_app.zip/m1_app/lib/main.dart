import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RadioM1App());
}

class RadioM1App extends StatelessWidget {
  const RadioM1App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const PlayerScreen(),
    );
  }
}

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    // Initialisiert den Web-Controller für die App
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF0B100E))
      ..clearCache() // Löscht den App-internen Cache bei jedem Start gegen Cache-Hänger
      ..loadRequest(Uri.parse('https://radio-m1.com')); // Lädt Ihren fertigen Player
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B100E),
      // SafeArea verhindert, dass das Handy-Display (Kamera-Ausschnitt/Notch) das Logo verdeckt
      body: SafeArea(
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}
